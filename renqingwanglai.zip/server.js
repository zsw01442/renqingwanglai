const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || '/app/data';
const RECORDS_FILE = path.join(DATA_DIR, 'records.json');
const GIFTBOOKS_FILE = path.join(DATA_DIR, 'giftbooks.json');

// 中间件
app.use(bodyParser.json());
app.use(express.static('public'));

// 确保数据目录存在
async function ensureDataDir() {
    try {
        await fs.access(DATA_DIR);
    } catch {
        await fs.mkdir(DATA_DIR, { recursive: true });
    }
}

// 读取数据
async function readData(file) {
    try {
        const data = await fs.readFile(file, 'utf8');
        return JSON.parse(data);
    } catch {
        return [];
    }
}

// 写入数据
async function writeData(file, data) {
    await fs.writeFile(file, JSON.stringify(data, null, 2));
}

// API 路由

// 获取所有记录
app.get('/api/records', async (req, res) => {
    try {
        const records = await readData(RECORDS_FILE);
        res.json(records);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 保存记录
app.post('/api/records', async (req, res) => {
    try {
        const records = req.body;
        await writeData(RECORDS_FILE, records);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 获取所有礼薄
app.get('/api/giftbooks', async (req, res) => {
    try {
        const giftbooks = await readData(GIFTBOOKS_FILE);
        res.json(giftbooks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 保存礼薄
app.post('/api/giftbooks', async (req, res) => {
    try {
        const giftbooks = req.body;
        await writeData(GIFTBOOKS_FILE, giftbooks);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 健康检查
app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

// 启动服务器
async function start() {
    await ensureDataDir();
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`人情往来系统运行在 http://0.0.0.0:${PORT}`);
        console.log(`数据存储目录: ${DATA_DIR}`);
    });
}

start();
