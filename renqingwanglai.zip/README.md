# 人情往来记录系统

一个用于记录和管理人情往来、随礼还礼的智能 Web 应用。

## ✨ 功能特点

- 📝 **记录管理**: 收礼/送礼记录，支持编辑和删除
- 📖 **礼薄功能**: 办事收礼登记，宾客管理
- 👥 **智能输入**: 姓名联想、自动填充
- 📊 **统计分析**: 年度统计、事由分析
- 🔐 **密码保护**: 默认密码 admin，首次登录提示修改
- 💾 **数据持久化**: Docker 卷挂载，数据永久保存
- 📱 **响应式设计**: 支持移动端访问
- 🔄 **数据同步**: 礼薄与记录双向同步

---

## 🚀 快速部署

### 方案一：Docker Hub 一键部署（推荐）

**适合**: 快速部署，无需本地构建

#### Linux/Mac:
```bash
# 下载并运行部署脚本
wget https://raw.githubusercontent.com/your-repo/renqing-wanglai/main/deploy-from-hub.sh
chmod +x deploy-from-hub.sh
./deploy-from-hub.sh
```

#### Windows PowerShell:
```powershell
# 下载并运行部署脚本
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/your-repo/renqing-wanglai/main/deploy-from-hub.ps1" -OutFile "deploy-from-hub.ps1"
.\deploy-from-hub.ps1
```

#### 手动部署:
```bash
# 拉取镜像
docker pull your-dockerhub-username/renqing-wanglai:latest

# 运行容器
docker run -d \
  --name renqing-wanglai \
  -p 3000:3000 \
  -v ~/renqing-data:/app/data \
  --restart unless-stopped \
  your-dockerhub-username/renqing-wanglai:latest

# 访问应用
# http://localhost:3000
```

📖 **详细说明**: 查看 [Docker Hub 部署文档](docker-hub-deploy.md)

---

### 方案二：本地构建部署

**适合**: 自定义修改，本地开发

#### 前置要求
- 已安装 Docker
- 已安装 Docker Compose

### 部署步骤

1. **创建目录结构**
```bash
mkdir -p public data
```

2. **移动 HTML 文件**
```bash
# 将 index.html 移动到 public 目录
mv index.html public/
```

3. **构建并启动容器**
```bash
docker-compose up -d
```

4. **访问应用**
打开浏览器访问：`http://localhost:3000` 或 `http://你的服务器IP:3000`

### 常用命令

#### 查看容器状态
```bash
docker-compose ps
```

#### 查看日志
```bash
docker-compose logs -f
```

#### 停止服务
```bash
docker-compose down
```

#### 重启服务
```bash
docker-compose restart
```

#### 更新应用
```bash
docker-compose down
docker-compose up -d --build
```

### 数据持久化

数据存储在 `./data` 目录下，包含：
- `records.json` - 人情往来记录
- `giftbooks.json` - 礼薄数据

**备份数据：**
```bash
cp -r ./data ./data_backup_$(date +%Y%m%d)
```

**恢复数据：**
```bash
cp -r ./data_backup_20231207/* ./data/
docker-compose restart
```

### 端口配置

默认端口：3000

修改端口（编辑 docker-compose.yml）：
```yaml
ports:
  - "8080:3000"  # 将 3000 改为你想要的端口
```

---

## 📋 使用说明

### 首次登录

1. 打开浏览器访问应用地址
2. 输入默认密码：`admin`
3. 登录后会提示修改密码
4. **强烈建议立即修改密码**

### 主要功能

#### 1. 添加记录
- 收礼记录：记录别人给你的礼金
- 送礼记录：记录你给别人的礼金
- 支持关联礼薄：自动填充事由和日期
- 智能联想：输入姓名时自动提示历史记录

#### 2. 礼薄管理
- 创建礼薄：记录自己办事时的收礼情况
- 添加宾客：自动创建收礼记录
- 编辑信息：礼薄和记录双向同步
- 导出功能：导出为文本格式

#### 3. 统计分析
- 年份统计：查看各年度收支情况
- 事由统计：分类统计各类事由
- 收支明细：详细的收支记录

### 密码管理

#### 修改密码
1. 在登录页点击"修改密码"
2. 输入旧密码和新密码
3. 确认后返回登录页

#### 忘记密码
如果忘记密码，可通过以下方式重置：

**方法1: 清除浏览器数据**
```javascript
// 浏览器控制台(F12)执行：
localStorage.removeItem('renqing-password');
localStorage.removeItem('renqing-first-time');
// 刷新页面，密码重置为 admin
```

**方法2: 删除容器数据**
```bash
# 停止容器
docker stop renqing-wanglai
# 删除容器
docker rm renqing-wanglai
# 重新运行（使用新的数据目录）
```

---

## 🔧 高级配置

## 🔧 高级配置

### 多实例部署

运行多个独立实例（不同端口）：
```bash
# 实例 1
docker run -d \
  --name renqing-instance-1 \
  -p 3000:3000 \
  -v ~/renqing-data-1:/app/data \
  your-dockerhub-username/renqing-wanglai:latest

# 实例 2
docker run -d \
  --name renqing-instance-2 \
  -p 3001:3000 \
  -v ~/renqing-data-2:/app/data \
  your-dockerhub-username/renqing-wanglai:latest
```

### 配置反向代理（Nginx）

创建 `nginx.conf`:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

### 配置 HTTPS

使用 Let's Encrypt:
```bash
# 安装 certbot
sudo apt install certbot python3-certbot-nginx

# 获取证书
sudo certbot --nginx -d your-domain.com
```

### 环境变量

在 docker-compose.yml 中配置：
- `PORT`: 应用端口（默认 3000）
- `DATA_DIR`: 数据存储目录（默认 /app/data）
- `NODE_ENV`: 运行环境（production）

### 资源限制

限制容器资源使用：
```yaml
services:
  renqing-app:
    # ... 其他配置
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          cpus: '0.25'
          memory: 256M
```

---

## 🔄 升级与维护

### 升级到最新版本

**Docker Hub 部署:**
```bash
# 停止容器
docker stop renqing-wanglai

# 删除容器（数据保留）
docker rm renqing-wanglai

# 拉取最新镜像
docker pull your-dockerhub-username/renqing-wanglai:latest

# 重新运行
docker run -d \
  --name renqing-wanglai \
  -p 3000:3000 \
  -v ~/renqing-data:/app/data \
  --restart unless-stopped \
  your-dockerhub-username/renqing-wanglai:latest
```

**本地构建:**
```bash
docker-compose down
docker-compose pull
docker-compose up -d --build
```

### 数据备份

**自动备份脚本（Linux/Mac）:**
```bash
#!/bin/bash
# backup.sh
BACKUP_DIR="$HOME/renqing-backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/renqing-backup-$DATE.tar.gz" ~/renqing-data

# 保留最近7天的备份
find "$BACKUP_DIR" -name "renqing-backup-*.tar.gz" -mtime +7 -delete
```

**定时备份（crontab）:**
```bash
# 每天凌晨2点备份
0 2 * * * /path/to/backup.sh
```

### 数据恢复

```bash
# 停止容器
docker stop renqing-wanglai

# 恢复数据
tar -xzf renqing-backup-20231207_020000.tar.gz -C ~

# 重启容器
docker start renqing-wanglai
```

---

## 📊 监控与日志

### 查看日志

```bash
# 实时查看日志
docker logs -f renqing-wanglai

# 查看最近100行
docker logs --tail 100 renqing-wanglai

# 查看特定时间范围
docker logs --since 1h renqing-wanglai
```

### 监控容器状态

```bash
# 查看容器状态
docker ps -a | grep renqing

# 查看资源使用
docker stats renqing-wanglai

# 查看详细信息
docker inspect renqing-wanglai
```

---

## 🛠 故障排查

#### 容器无法启动
```bash
docker-compose logs
```

#### 数据未持久化
检查 data 目录权限：
```bash
chmod -R 755 ./data
```

#### 无法访问
检查防火墙设置，开放 3000 端口：
```bash
# Linux
sudo ufw allow 3000

# Windows
# 在防火墙设置中添加入站规则
```

#### 端口被占用
```bash
# 查看端口占用
netstat -ano | findstr :3000  # Windows
lsof -i :3000                 # Linux/Mac

# 使用其他端口
docker run -d \
  --name renqing-wanglai \
  -p 8080:3000 \
  -v ~/renqing-data:/app/data \
  your-dockerhub-username/renqing-wanglai:latest
```

#### 镜像拉取失败
```bash
# 检查网络连接
ping hub.docker.com

# 配置镜像加速器
# 编辑 /etc/docker/daemon.json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://registry.docker-cn.com"
  ]
}

# 重启 Docker
sudo systemctl restart docker
```

#### 数据丢失
```bash
# 检查卷挂载
docker inspect renqing-wanglai | grep Mounts -A 10

# 确认数据目录
ls -la ~/renqing-data
```

---

## 📚 文档

- [Docker Hub 部署指南](docker-hub-deploy.md) - 从 Docker Hub 拉取镜像部署
- [推送镜像到 Docker Hub](push-to-dockerhub.md) - 构建并发布自己的镜像
- [详细部署文档](DEPLOYMENT.md) - 完整的部署和配置说明

---

## 🔒 安全建议

## 🔒 安全建议

1. **立即修改默认密码**: 首次登录后务必修改 admin 密码
2. **限制网络访问**: 使用防火墙限制访问来源
3. **使用 HTTPS**: 生产环境配置 SSL 证书
4. **定期备份**: 设置自动备份任务
5. **及时更新**: 定期更新 Docker 镜像和依赖
6. **监听本地**: 如非必要，只监听 127.0.0.1
   ```bash
   docker run -d \
     --name renqing-wanglai \
     -p 127.0.0.1:3000:3000 \
     -v ~/renqing-data:/app/data \
     your-dockerhub-username/renqing-wanglai:latest
   ```

---

## 🗑 卸载

```bash
# 停止并删除容器
docker stop renqing-wanglai
docker rm renqing-wanglai

# 删除镜像
docker rmi your-dockerhub-username/renqing-wanglai:latest

# 删除数据（可选，注意会永久删除数据）
rm -rf ~/renqing-data
```

---

## 💡 技术栈

### 前端
- HTML5
- CSS3 (响应式设计)
- JavaScript (原生，无框架)

### 后端
- Node.js 18
- Express.js
- Body-parser

### 存储
- JSON 文件持久化
- Docker 卷挂载

### 容器化
- Docker
- Docker Compose
- Alpine Linux 基础镜像

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

---

## 📞 技术支持

- **GitHub Issues**: [提交问题](https://github.com/your-repo/renqing-wanglai/issues)
- **Docker Hub**: [镜像仓库](https://hub.docker.com/r/your-dockerhub-username/renqing-wanglai)

---

## 📄 许可证

MIT License
